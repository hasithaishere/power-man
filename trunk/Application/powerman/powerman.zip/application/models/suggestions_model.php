<?php

class suggestions_model extends CI_Model
{
	function give_user_suggestions()
	{
		//$this->db->where('status','1');
		//$this->db->where('user_id',$this->session->userdata('user_id'));
		//$result = $this->db->get('power_location')->result_array();
		
		//return $result;
	}
	
}