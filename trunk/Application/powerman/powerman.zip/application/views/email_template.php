<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

</head>

<meta name="ROBOTS" content="NOINDEX, NOFOLLOW">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="format-detection" content="telephone=no"> 
<title></title>
<style type="text/css"> 
.ReadMsgBody { width: 100%;}
.ExternalClass {width: 100%;}
.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height: 100%;}
body {-webkit-text-size-adjust:none; -ms-text-size-adjust:none;}
body {margin:0; padding:0}
table td {border-collapse:collapse;}
a, a:link {color:#2A5DB0;text-decoration: underline;}
p {margin:0; padding:0}
/* Media Query Styles */
@media only screen and (max-device-width: 480px){
	body[yahoo] table[id="emailContent"]{
		max-width:600px !important;
		width:100% !important;
	}
	
	body[yahoo] td[class="welcomeContent"]{
		font-size:23px !important;
		line-height:30px !important;
	}
	
	body[yahoo] td[class="promoContent"]{
		font-size:18px !important;
		line-height:26px !important;
		width:444px !important;
	}
	
	body[yahoo] img[class="promoImage"]{
		width:56px !important;
		height:59px !important;
	}
	
	body[yahoo] td[class="promoImage"]{
		width:84px !important;
	}
	
	body[yahoo] td[class="bodyContent"]{
		font-size:20px !important;
		line-height:26px !important;
	}
	
	body[yahoo] img[class="account-cta"]{
		width:228px !important;
		height:70px !important;
	}
	
	body[yahoo] td[class="footer-left"]{
		width:308px !important;
	}
	
	body[yahoo] td[class="footer-right"]{
		width:160px !important;
		font-size:13px !important;
	}
	
</style>


<center>


<table id="emailContent" border="0" cellpadding="0" cellspacing="0">
	<!-- HEADER IMAGE -->
    <tbody style="background-color:#CCC">
    <tr>
    	<td colspan="3" width="600">
        	<table border="0" cellpadding="0" cellspacing="0">
            	<tbody><tr>
                    <td colspan="3" style="line-height:0; font-size:0;" align="center" width="600"><a href="http://www.domore.lk"><img class="header" src="<?php echo base_url();?>img/email_template/header-welcome-plain.png" alt="Welcome to Domore" title="Welcome to Domore" style="display:block;" border="0" height="69" width="600"></a></td>
                </tr>
            </tbody></table>
        </td>
    </tr>
    <!-- BODY CONTENT -->
    <tr>
    	<td width="36">&nbsp;</td>
        <td width="528">
        	<table border="0" cellpadding="0" cellspacing="0">
                <tbody>
                <tr>
                    <td style="color:#3f3f3f; font-family:Helvetica, Arial, sans-serif; font-size:20px; line-height:50px;padding:0; margin:0; margin-bottom:0;" align="left" width="528"><strong>Welcome to Domore Technologies PowerMan Solutions</strong></td>
                </tr>
                <tr>
                	<td style="font-size:6px; line-height:6px;" width="528">&nbsp;</td>
                </tr>
                <tr>
                    <td style="color:#3f3f3f; font-family:Helvetica, Arial, sans-serif; font-size:30px; margin:0; padding:0; line-height:30px;" align="left" width="528"><strong>It's great to have you on board</strong></td>
                </tr>
                <tr>
                	<td style="font-size:10px; line-height:12px;" width="528">&nbsp;</td>
                </tr>
                <tr>
                    <td class="welcomeContent" style="color:#3f3f3f; font-family:Helvetica, Arial, sans-serif; font-size:18px; line-height:22px; border-bottom:1px solid #e4e4e4;" align="left" width="528">You've taken the first step, now it's time to make the most of the opportunities available to you.<br><br></td>
                </tr>
                <tr>
                	<td style="font-size:14px; line-height:18px;" width="528">&nbsp;</td>
                </tr>
                <tr>
                	<td width="528">
                    	<table border="0" cellpadding="0" cellspacing="0">
                        	<tbody><tr>
                            	<td rowspan="2" class="promoImage" align="left" width="54"><a href="#"><img src="<?php echo base_url();?>img/email_template/welcome-icon-profile.png" alt="Temporary Authentication" title="Temporary Authentication" class="promoImage" border="0" height="42" width="40"></a></td>
                            	<td class="promoContent" style="color:#111111; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:16px; font-weight:bold;" align="left" width="474">Temporary Authentication</td>
                              
                            </tr>
                            <tr>
                            	<td class="promoContent" style="color:#111111; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:16px;" align="left" width="474">
                                 User Name: <span style="font-weight:bold;"><?php echo $email;?></span><br>
                                 Password : <span style="font-weight:bold;"><?php echo $password;?></span></td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
                <tr>
                	<td style="font-size:20px; line-height:28px;" width="528">&nbsp;</td>
                </tr>
                <tr>
                	<td width="528">
                    	<table border="0" cellpadding="0" cellspacing="0">
                        	<tbody><tr>
                            	<td rowspan="2" class="promoImage" align="left" width="54"><a href="#"><img src="<?php echo base_url();?>img/email_template/welcome-icon-jobmail.png" alt="Email code" title="Email code" class="promoImage" border="0" height="42" width="40"></a></td>
                            	<td class="promoContent" style="color:#111111; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:18px; font-weight:bold;" align="left" width="474">Email Validation Code</td>
                            </tr>
                            <tr>
                            	<td class="promoContent" style="color:#111111; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:18px;" align="left" width="474">Enter this code to complete your registration in our site.<br>Validate Code : <span style="font-weight:bold;"><?php echo $email_code;?></span></td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
                <tr>
                	<td style="font-size:20px; line-height:28px;" width="528">&nbsp;</td>
                </tr>
                <tr>
                	<td width="528">
                    	<table border="0" cellpadding="0" cellspacing="0">
                        	<tbody><tr>
                            	<td rowspan="2" class="promoImage" align="left" width="54"><a href="#"><img src="<?php echo base_url();?>img/email_template/welcome-icon-fav.png" alt="Get organised" title="Get organised" class="promoImage" border="0" height="42" width="40"></a></td>
                            	<td class="promoContent" style="color:#111111; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:18px; font-weight:bold;" align="left" width="474">Mobile Phone Validation Code</td>
                            </tr>
                            <tr>
                            	<td class="promoContent" style="color:#111111; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:18px;" align="left" width="474"><a href="#">Generate the Phone Code</a> and complete the next step of the registration.</td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
                <tr>
                	<td style="font-size:20px; line-height:28px;" width="528">&nbsp;</td>
                </tr>
                <tr>
                	<td width="528">
                    	<table border="0" cellpadding="0" cellspacing="0">
                        	<tbody><tr>
                            	<td rowspan="2" class="promoImage" align="left" width="54"><a href="#"><img src="<?php echo base_url();?>img/email_template/welcome-icon-resume.png" alt="Apply anywhere" title="Apply anywhere" class="promoImage" border="0" height="42" width="40"></a></td>
                            	<td class="promoContent" style="color:#111111; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:18px; font-weight:bold;" align="left" width="474">Our Service Information</td>
                            </tr>
                            <tr>
                            	<td class="promoContent" style="color:#111111; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:18px;" align="left" width="474">Save your time and check us from your <a href="#" style="color:#0066cc; text-decoration:none;">mobile</a>, tablet and desktop!</td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
                <tr>
                	<td style="font-size:20px; line-height:28px;border-bottom:1px solid #e4e4e4" width="528">&nbsp;</td>
                </tr>
                <tr>
                	<td style="font-size:14px; line-height:18px;" width="528">&nbsp;</td>
                </tr>
                <tr>
                	<td align="left" width="528">
                    	<table border="0" cellpadding="0" cellspacing="0">
                        	<tbody><tr>
                                <td class="bodyContent" style="color:#111111; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:14px;" align="left" width="300">
                               <br>
                                Customer Service Manager<br><br>Domore Technologies(Pvt) Limited
                                </td>
                                <td style="vertical-align:top;" align="right" width="228">
                                    <a href="<?php echo base_url(); ?>" target="_blank"><img src="<?php echo base_url();?>img/email_template/account-button.png" alt="Go to My Account" title="Go to My Account" class="account-cta" border="0" height="53" width="166"></a></td>
                         	</tr>
                         </tbody></table>
                     </td>
                 </tr><tr>
                	<td style="font-size:20px; line-height:28px;" width="528">&nbsp;</td>
                </tr>
            </tbody></table>
        </td>
        <td width="36">&nbsp;</td>
    </tr>
    <!-- FOOTER -->
    <tr>
    	<td colspan="3" style="background:#3f3f3f;" bgcolor="#3f3f3f" width="600">
        	<table border="0" cellpadding="0" cellspacing="0">
            	<tbody><tr>
                    <td style="background:#3f3f3f;border-bottom:1px solid #9b9b9b;" width="36">&nbsp;</td>
                    <td style="background:#3f3f3f;border-bottom:1px solid #9b9b9b;" width="528">
                        <table border="0" cellpadding="0" cellspacing="0">
                            <tbody><tr>
                                <td class="footer-left" style="color:#808080; line-height:16px; font-family:Arial, Helvetica, sans-serif; font-size:11px;" align="left" width="528"><br><a href="#" style="text-decoration:none; color:#808080;">Privacy</a> | <a href="#" style="text-decoration:none; color:#808080;">Contact Us</a><br><br>
                                This email was sent to you as a registered user of <a href="http://www.domore.lk" style="color:#808080;">www.domore.lk</a><br><br></td></tr>
                        </tbody></table>
                    </td>
                    <td style="background:#3f3f3f;border-bottom:1px solid #9b9b9b;" width="36">&nbsp;</td>
                </tr>
                <tr>
                    <td style="background:#3f3f3f" width="36">&nbsp;</td>
                    <td style="background:#3f3f3f" width="528">
                        <table border="0" cellpadding="0" cellspacing="0">
                            <tbody><tr>
                                <td style="color:#fff; font-family:Arial, Helvetica, sans-serif; font-weight:bold; font-size:11px;" align="left" width="364"><br>© Domore Technologies(Pvt) Limited 2013. All rights reserved.<br><br></td>
                                <td style="color:#fff; font-family:Arial, Helvetica, sans-serif; font-weight:normal; font-size:11px;" align="right" width="200"><br></td>
                            </tr>
                        </tbody></table>
                    </td>
                    <td style="background:#3f3f3f" width="36">&nbsp;</td>
                </tr>
            </tbody></table>
        </td>
    </tr>
</tbody></table>
</center>

</body></html>