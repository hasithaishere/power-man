<footer>
			<p>
				<span style="text-align:left;float:left">&copy; <a href="#" target="_blank">Power Man</a> 2013</span>
				<span style="text-align:right;float:right">Powered by: <a href="www.domore.lk">Domore Technologies (Pvt) Limited</a></span>
			</p>

</footer>