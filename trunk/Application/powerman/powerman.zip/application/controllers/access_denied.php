<?php

class access_denied extends CI_Controller
{
	function index()
	{
		$this->load->view('access_denied');
	}
	
}