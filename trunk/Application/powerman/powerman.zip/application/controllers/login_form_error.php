<?php

class login_form_error extends CI_Controller
{
	
	function index()
	{
		$this->load->view('login_form_error');
	}
	
}