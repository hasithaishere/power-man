<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['sms_server_url'] = 'http://hasithaonline.capnix.com/sms/send_sms.php';
$config['sms_code'] = '6f78079088bd1bbc06cc277af294951a';
